import random


def run_game():
    code_list = []
    while len(code_list) < 4:
        code_num = random.randint(1,8)
        if code_num not in code_list:          #This If statement ensures there are no duplicate digits
            code_list.append(code_num)
    
    
    #print(code_list)
    print('4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.')

    turns = 12
    while turns > 0:
        user_input = input("Input 4 digit code: ")
        
        while len(user_input) != 4 or not user_input.isdigit():
            print("Please enter exactly 4 digits.")
            user_input = input("Input 4 digit code: ")
       
        correct_digits_place = 0
        correct_digits = 0

        for i in range(len(user_input)):
            if code_list[i] == int(user_input[i]):
                correct_digits_place += 1
            elif int(user_input[i]) in code_list:
                correct_digits += 1

        print("Number of correct digits in correct place:    ",correct_digits_place)
        print("Number of correct digits not in correct place:",correct_digits)
         
             
        if  correct_digits_place == 4:
            print("Congratulations! You are a codebreaker!")
            print("The code was:",user_input)
            break
        
        turns -= 1
        print("Turns left:",turns)


if __name__ == "__main__":
    run_game()
